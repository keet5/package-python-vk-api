__version__ = "0.1.0"

from .vk_api import VkApi
